# Organose.gr

Το Organose είναι ένα SaaS σύστημα για συλλόγους γονέων, όπου κάθε σύλλογος αποκτά το δικό του subdomain και πλήρη διαχείριση.

## Δυνατότητες

- Δημιουργία νέου συλλόγου από admin panel
- Αυτόματη εγκατάσταση WordPress
- Προκαθορισμένο plugin (eGrammateia)
- Email καλωσορίσματος

## Οδηγίες

1. Ρύθμισε wildcard DNS (*.organose.gr)
2. Συμπλήρωσε το config/db.json με στοιχεία MySQL
3. Από το /manager/index.php πρόσθεσε νέους συλλόγους
